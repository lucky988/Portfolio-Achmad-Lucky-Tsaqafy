<html>

<head>
    <title>coba 1</title>
</head>

<body>
    Halo Kawan.. Yuk kita belajar web programming..!!!<br>
    Nilai 1 = <?= $nilai1; ?>
    Nilai 2 = <?= $nilai2; ?>
    ini hasil dari pemodelan dengan methode penjumlahan yaitu <?= $nilai1 . " + " . $nilai2 . " = " . $hasil; ?>
</body>

</html>
