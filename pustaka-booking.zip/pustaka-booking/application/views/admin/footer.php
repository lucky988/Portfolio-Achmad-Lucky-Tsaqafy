</div>
<script type="text/javascript">
	$(document).ready(function(){
		$("#table-datatable").dataTable();
	});
	$('.alert-message').alert().delay(3000).slideUp('slow');
</script>
</body>
</html>