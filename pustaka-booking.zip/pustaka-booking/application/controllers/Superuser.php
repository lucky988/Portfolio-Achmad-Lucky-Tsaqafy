<?php

class Superuser extends CI_Controller
{
    public function index()
    {
        redirect('autentifikasi');
    }
}
